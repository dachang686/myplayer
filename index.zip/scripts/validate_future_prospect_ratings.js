const fs = require('fs');
const vm = require('vm');

const draftSource = fs.readFileSync('js/data/draft_data.js', 'utf8');
const configSource = fs.readFileSync('js/data/simulation_config.js', 'utf8');
const indexSource = fs.readFileSync('index.html', 'utf8');
const offseasonSource = fs.readFileSync('js/offseason.js', 'utf8');
const draftEngineSource = fs.existsSync('js/draft.js') ? fs.readFileSync('js/draft.js', 'utf8') : '';
const rookieFlowSource = `${offseasonSource}\n${draftEngineSource}`;
const evidence = JSON.parse(fs.readFileSync('scripts/data/future_prospect_profiles.json', 'utf8')).profiles;
const reviews = JSON.parse(fs.readFileSync('scripts/data/future_prospect_reviews.json', 'utf8')).reviews;
const fairAdjustments = JSON.parse(fs.readFileSync('scripts/data/fair_ovr_rookie_adjustments.json', 'utf8')).players
  .filter((row) => row.cohort === 'future');
const context = {};
vm.createContext(context);
vm.runInContext(configSource, context);
vm.runInContext(draftSource, context);

const ratings = vm.runInContext('FUTURE_PROSPECT_RATINGS', context);
const configAttrKeys = vm.runInContext('SIM_CONFIG.ATTR_LIST', context);
context.ATTR_KEYS = configAttrKeys;
context.STATE = { position: 'SG' };
const ovrStart = offseasonSource.indexOf('function getOvrPositions');
const ovrEnd = offseasonSource.indexOf('function getCurrentLeagueSeasonNumber', ovrStart);
if (ovrStart >= 0 && ovrEnd > ovrStart) {
  vm.runInContext(offseasonSource.slice(ovrStart, ovrEnd), context, { filename: 'future-prospect-ovr.js' });
}
const candidates = vm.runInContext('DRAFT_CLASS_2027.concat(ROOKIE_NAMES)', context);
const candidatePools = vm.runInContext('DRAFT_CLASS_2027.concat(ROOKIE_NAMES, STAR_ROOKIES)', context);
const attrKeys = configAttrKeys;
const profilesByPosition = {
  PG: ['playmaker', 'scoring_guard'],
  SG: ['perimeter_scorer', 'two_way_slasher'],
  SF: ['two_way_wing', 'point_forward'],
  PF: ['interior_forward', 'stretch_four'],
  C: ['rim_protector', 'skilled_big']
};
const errors = [];
const candidateById = Object.fromEntries(candidates.map((candidate) => [candidate.id, candidate]));
const evidenceById = {};
const reviewById = {};
const fairAdjustmentById = Object.fromEntries(fairAdjustments.map((row) => [row.id, row]));

evidence.forEach((profile) => {
  if (evidenceById[profile.id]) errors.push(`${profile.id} 证据档案重复`);
  evidenceById[profile.id] = profile;
});
reviews.forEach((review) => {
  if (reviewById[review.id]) errors.push(`${review.id} 审核记录重复`);
  reviewById[review.id] = review;
});

Object.keys(ratings).forEach((id) => {
  const rating = ratings[id];
  const candidate = candidateById[id];
  const profile = evidenceById[id];
  const review = reviewById[id];
  if (!candidate) errors.push(`${id} 不在未来候选名单`);
  if (!profile) errors.push(`${id} 缺少证据档案`);
  if (!review || review.status !== 'confirmed') errors.push(`${id} 缺少已确认审核记录`);
  if (profile && review && profile.name !== review.name) errors.push(`${id} 证据名 ${profile.name} 与审核名 ${review.name} 不一致`);
  if (!rating || !vm.runInContext(`!!SIM_CONFIG.OVR_MODEL.positionWeights[${JSON.stringify(rating && rating.pos)}]`, context)) errors.push(`${id} 位置无效`);
  if (!rating.height) errors.push(`${id} 缺少身高`);
  const fairAdjustment = fairAdjustmentById[id];
  if (!fairAdjustment) errors.push(`${id} 缺少公平 OVR 属性审计`);
  Object.entries((fairAdjustment && fairAdjustment.changes) || {}).forEach(([key, tuple]) => {
    if (key === 'STL' || !attrKeys.includes(key) || !Array.isArray(tuple) || tuple.length !== 2 || rating.attributes[key] !== tuple[1]) {
      errors.push(`${id} 公平 OVR 属性审计无效：${key}`);
    }
  });
  if (!profilesByPosition[rating.pos] || !profilesByPosition[rating.pos].includes(rating.profile)) errors.push(`${id} 模板 ${rating.profile} 与位置 ${rating.pos} 不匹配`);
  attrKeys.forEach((key) => {
    const value = rating.attributes && rating.attributes[key];
    if (!Number.isInteger(value) || value < 25 || value > 99) errors.push(`${id} ${key} 无效：${value}`);
  });
  if (rating && rating.attributes && ovrStart >= 0 && ovrEnd > ovrStart) {
    context.ratingProbe = { pos: rating.pos, ovr: rating.ovr, ...rating.attributes };
    const directCalculated = vm.runInContext('calcOVR(ratingProbe, ratingProbe.pos)', context);
    if (Math.abs(directCalculated - rating.ovr) > 2) errors.push(`${id} 公平公式实算偏差超过 2：${directCalculated} / ${rating.ovr}`);
    vm.runInContext(`normalizeRookieAttributesToOvr(ratingProbe, ${Number(rating.ovr)})`, context);
    const calculated = vm.runInContext('calcOVR(ratingProbe, ratingProbe.pos)', context);
    if (calculated !== rating.ovr) errors.push(`${id} 新公式归一失败：目标 ${rating.ovr}，实算 ${calculated}`);
  }
});

evidence.forEach((profile) => {
  if (!ratings[profile.id]) errors.push(`${profile.id} 有证据档案但尚无固定评分`);
});
reviews.forEach((review) => {
  if (!ratings[review.id]) errors.push(`${review.id} 有审核记录但尚无固定评分`);
});
candidatePools.forEach((candidate) => {
  if (Object.prototype.hasOwnProperty.call(candidate, 'name')) errors.push(`${candidate.id} 仍含临时英文名字段`);
  if (!candidate.id || !candidate.cn) errors.push(`${candidate.id || '未知候选'} 缺少稳定 ID 或中文名`);
});

if (!/FUTURE_PROSPECT_RATINGS\[pick\.ratingId\s*\|\|\s*pick\.id\]/.test(indexSource)) errors.push('generateRookie 未读取未来球员固定评级');
if (!/height:\s*fixedRating\s*\?\s*fixedRating\.height/.test(indexSource)) errors.push('generateRookie 未使用固定身高');
if (!/_usedRookieCandidateNames\[pick\.ratingId\]\s*=\s*true/.test(indexSource)) errors.push('明星评级身份未同步去重，可能重复生成');
const fixedBranches = rookieFlowSource.match(/(?:rookie|rk|player)\._fixedProspectRating/g) || [];
if (fixedBranches.length < 2) errors.push('正常选秀或补位流程仍可能覆盖固定评级');
if (!/normalizeRookieAttributesToOvr\((?:rookie|player), (?:rookie|player)\.ovr\)/.test(rookieFlowSource)) errors.push('未来固定新秀未按审核 OVR 归一属性');
if (!/normalizeRookieAttributesToOvr\((?:rk|player), (?:rk|player)\.ovr\)/.test(rookieFlowSource)) errors.push('补位固定新秀未按审核 OVR 归一属性');

console.log(JSON.stringify({
  fixedFutureRatings: Object.keys(ratings).length,
  evidenceProfiles: evidence.length,
  confirmedReviews: reviews.filter((review) => review.status === 'confirmed').length,
  fairOvrAdjustments: fairAdjustments.length,
  validationErrors: errors.length,
  errors
}, null, 2));
if (errors.length) process.exit(1);
