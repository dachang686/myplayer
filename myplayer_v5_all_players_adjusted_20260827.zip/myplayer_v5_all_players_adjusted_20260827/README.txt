MYPLAYER V5 全联盟球员属性调整版

替换文件：
  js/data/league_players.js

内容：
- 30 支球队、525 名球员
- 全联盟按 V5 统一模型重新整理的属性版本
- 同时附带 adjustment_metrics.json，记录整体残差、排名和属性调整统计

使用方法：
1. 备份项目原 js/data/league_players.js
2. 将本压缩包中的 js/data/league_players.js 覆盖到项目同名路径
3. 运行项目现有 V5/V2 正式门禁

SHA-256：
league_players.js  d6f4454d5f6a9fc74150f830136758a1169165c158ac29b39205ef3cf34999b8
adjustment_metrics.json  c2887cd97c844722e88f64d49a815005f3da0edc9fec689b295515f3f21765ad
